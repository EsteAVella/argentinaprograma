package com.portfolio.AvellaEsteban;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvellaEstebanApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvellaEstebanApplication.class, args);
	}

}
