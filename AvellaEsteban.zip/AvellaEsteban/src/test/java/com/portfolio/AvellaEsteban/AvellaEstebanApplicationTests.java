package com.portfolio.AvellaEsteban;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvellaEstebanApplicationTests {

	@Test
	void contextLoads() {
	}

}
